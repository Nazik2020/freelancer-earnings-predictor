import pandas as pd
import os

_SERVER_DIR = os.getcwd()
CLEAN_DATASET_PATH = os.path.normpath(
    os.path.join(_SERVER_DIR, '..', 'dataset', 'df7.csv')
)

JOB_CAT_MAP = {0: 'App Development', 1: 'Content Writing', 2: 'Customer Support', 
               3: 'Data Entry', 4: 'Digital Marketing', 5: 'Graphic Design', 
               6: 'SEO', 7: 'Web Development'}

try:
    df = pd.read_csv(CLEAN_DATASET_PATH)
    df['Job_Label'] = df['Job_Category'].map(JOB_CAT_MAP)
    stats = df.groupby('Job_Label')['Earnings_USD'].mean().sort_values(ascending=False)
    print("--- Stats from df7.csv ---")
    print(stats)
except Exception as e:
    print(f"Error: {e}")
